package stevejobs;
public abstract class Example7 
{
	public int add(int x, int y)
	{
		int z;
		z=x+y;
		return(z);
	}
	public abstract int substract(int x, int y);
}





