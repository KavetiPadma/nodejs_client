package stevejobs;
public class Example8
{
	public int x;
	public Example8()
	{
		x=10;
	}
	public void display()
	{
		System.out.println(x);
	}
}



