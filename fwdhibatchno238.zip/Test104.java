package stevejobs;

public class Test104
{
	public static void main(String[] args) 
	{
		String x="My name is khan";
		String y="is";
		if(x.contains(y))
		{
			System.out.println("exists");
		}
		else
		{
			System.out.println("not exist");                         
		}

	}

}
