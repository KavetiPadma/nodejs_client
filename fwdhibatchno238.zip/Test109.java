package stevejobs;

public class Test109
{
	public static void main(String[] args) 
	{
		String x="my name is khan";
		String y=x.replace(" ","");
		System.out.println(y);
	}

}
