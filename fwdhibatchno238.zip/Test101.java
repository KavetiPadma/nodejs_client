package stevejobs;

import java.util.Scanner;

public class Test101 {

	public static void main(String[] args)
	{
		System.out.println("Enter data");
		Scanner sc=new Scanner(System.in);
		int y=Integer.parseInt(sc.nextLine());
		String x=sc.nextLine();
	}
}





