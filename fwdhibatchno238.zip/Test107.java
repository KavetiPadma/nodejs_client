package stevejobs;
public class Test107
{
	public static void main(String[] args)
	{
		String x="chack de india";
		String y[]=x.split(" "); //blank space as separator
		System.out.println(y.length);
		for(int i=0;i<y.length;i++)
		{
			System.out.println(y[i]);
		}
	}

}
