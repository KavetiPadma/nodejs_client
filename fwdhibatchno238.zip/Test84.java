package stevejobs;
public class Test84
{
	public static void main(String[] args) 
	{
		Example2 obj=new Example2();
		obj.method1();
	}
}







