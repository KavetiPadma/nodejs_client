package stevejobs;
public class Test83
{
	public static void main(String[] args) 
	{
		Example1 obj=new Example1();
		obj.method1();
	}
}







