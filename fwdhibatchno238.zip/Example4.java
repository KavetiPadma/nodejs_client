package stevejobs;
public class Example4
{
	//Data members
	public int x, y, z;
	//Operational methods
	public int add(int a)
	{
		x=a;
		int r=x+y+z;
		return(r);
	}
	public int add(int a, int b)
	{
		x=a;
		y=b;
		int r=x+y+z;
		return(r);
	}
	public int add(int a, int b, int c)
	{
		x=a;
		y=b;
		z=c;
		int r=x+y+z;
		return(r);
	}
}




