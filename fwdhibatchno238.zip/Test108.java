package stevejobs;
public class Test108
{
	public static void main(String[] args) 
	{
		String x="Chack de india";
		String y=x.replace('a','*');
		System.out.println(y);

	}

}
