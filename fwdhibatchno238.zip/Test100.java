package stevejobs;

import java.util.Scanner;

public class Test100
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter day number");
		int x=sc.nextInt();
		switch(x)
		{
		case 1:
			System.out.println("Sunday");
			break;
		case 2:
			System.out.println("Sunday");
			break;
		case 3:
			System.out.println("Sunday");
			break;
		case 4:
			System.out.println("Sunday");
			break;
		case 5:
			System.out.println("Sunday");
			break;
		case 6:
			System.out.println("Sunday");
			break;
		case 7:
			System.out.println("Sunday");
			break;
		default:
			System.out.println("Wrongday");
			break;
		}

	}

}
