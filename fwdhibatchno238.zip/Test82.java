package stevejobs;
import org.sikuli.script.Screen;
public class Test82
{
	public static void main(String[] args)
	{
		int x=10; //variable
		Screen s=new Screen();//object
		String z="mindq"; //object, but behave like variable
		System.out.println(z);
		System.out.println(z.length());
		
		

	}

}




