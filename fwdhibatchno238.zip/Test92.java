package stevejobs;
public class Test92
{
	public static void main(String[] args)
	{
		Example10 objref=Example10.create();
		objref.display(); //10
	}
}








