package stevejobs;

public class Test87 
{
	public static void main(String[] args) 
	{
		Example5.method123();
	}
}
