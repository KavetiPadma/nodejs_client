package stevejobs;
public class Bodies extends Example7 
{
	public int substract(int x, int y)
	{
		int z;
		z=x-y;
		return(z);
	}
}






