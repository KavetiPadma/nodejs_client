package stevejobs;
public class Test102
{
	public static void main(String[] args)
	{
		String x="chack de india";
		int l=x.length();
		System.out.println(l); //14
	}
}
