package stevejobs;
public class Test91 
{
	public static void main(String[] args)
	{
		Example8 obj1=new Example8();
		obj1.display();
		Example9 obj2=new Example9();
		obj2.display();
	}
}





