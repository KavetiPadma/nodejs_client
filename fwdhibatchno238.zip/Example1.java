package stevejobs;
public class Example1 
{
	//Data members
	public int x;
	public float y;
	public char z;
	public boolean w;
	public String s;
	//methods
	public void method1()
	{
		System.out.println(x+"\n"+y+"\n"+z+"\n"+w+"\n"+s);
	}
}






