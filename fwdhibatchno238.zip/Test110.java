package stevejobs;

import java.util.ArrayList;

public class Test110
{
	public static void main(String[] args) 
	{
		ArrayList<String> x=new ArrayList<String>();
		x.add("Amar");
		x.add("Akber");
		x.add("Antony");
		String z="";
		String y=z.join(" ",x);
		System.out.println(y);
		
		

	}

}
