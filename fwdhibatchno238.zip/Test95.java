package stevejobs;
public class Test95
{
	public static void main(String[] args)
	{
		int x=10;
		String y="janapath";
		String z=x+y; 
		System.out.println(z); //concatenation

	}

}
