package stevejobs;
public class Test85
{
	public static void main(String[] args)
	{
		Example3 obj1=new Example3();
		obj1.method1();
		Example3 obj2=new Example3(22,'T',"kalam");
		obj2.method1();
	}
}







