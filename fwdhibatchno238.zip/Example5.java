package stevejobs;
public class Example5
{
	public static int x=10;
	public static int y;
	public static void method123()
	{
		System.out.println(x+" "+y);
	}
}






